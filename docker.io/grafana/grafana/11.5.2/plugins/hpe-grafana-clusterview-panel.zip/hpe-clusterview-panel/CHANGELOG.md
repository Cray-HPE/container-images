# Changelog

## 1.1.0

Grafana 9.x support
Fix for Safari browser

## 1.0.0

Initial release.

