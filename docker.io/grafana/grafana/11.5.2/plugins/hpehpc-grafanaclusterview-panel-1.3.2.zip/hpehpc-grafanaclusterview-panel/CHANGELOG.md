# Changelog

## 1.2.0
* Remove extra nodes when when aggregate is not used
* documentation and text cleanup
* publicly released

## 1.1.0

* Grafana 9.x support
* Fix for Safari browser

## 1.0.0

* Initial release.
